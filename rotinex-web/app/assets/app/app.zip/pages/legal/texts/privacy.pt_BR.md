# Política de Privacidade do Rotinex

**Versão 2026-11 · Rascunho sujeito a revisão jurídica.** Este texto ainda será revisado por um advogado especializado em proteção de dados antes do lançamento.

O Rotinex é um aplicativo para organizar as áreas da sua vida (finanças, rotina, treino, alimentação, saúde, casa, estudos, carreira, beleza, viagens e pets). Para funcionar, ele guarda informações que você mesma(o) registra. Esta política explica, em linguagem simples, quais dados tratamos, para quê, com quem e como você controla tudo isso, conforme a Lei Geral de Proteção de Dados (LGPD, Lei 13.709/2018).

## 1. Quem cuida dos seus dados

O controlador dos dados é **Maria Thereza Alexandre Monteiro**, pessoa física, de Nazaré da Mata (PE).

Para qualquer assunto de privacidade, inclusive para exercer seus direitos, escreva para **rotinexapp@gmail.com**. Respondemos em até 15 dias.

## 2. Quais dados tratamos

- **Conta:** e-mail, senha (guardada apenas de forma cifrada pelo serviço de login, nunca por nós), como você prefere ser chamada(o), idioma, moeda, tema e a ordem das áreas no menu. Se você entrar com o Google, recebemos o nome e o e-mail da sua conta Google.
- **O que você registra em cada área:** lançamentos e contas de finanças, hábitos, tarefas e metas, treinos e medidas do corpo, refeições e lista de compras, informações de saúde, tarefas da casa, estudos, carreira, cuidados de beleza, viagens, informações dos seus pets, desafios e modo sono, recompensas e sugestões enviadas.
- **Dados de saúde (dados sensíveis):** sono, remédios, consultas, exames, humor, ciclo menstrual (desligado por padrão), medidas e peso, batimentos e calorias de treinos importados. Só tratamos esses dados com o seu **consentimento específico**, pedido separadamente no cadastro.
- **Anexos:** arquivos que você escolher anexar (comprovantes, exames, documentos). Com a sua conta, eles são **cifrados** pela nossa API e guardados numa pasta privada só sua no Supabase (região de São Paulo). Sem conta, ficam só no seu aparelho.
- **Melhorias do produto:** as sugestões e os problemas que você enviar e os seus votos nas ideias da equipe. Eles são lidos pela equipe do Rotinex sem o seu nome ou e-mail; por isso, pedimos que você não escreva dados pessoais neles.
- **Lançar com IA:** o texto que você escreve ou o áudio que você grava na página IA, apenas no momento de organizar. Guardamos só quantas vezes você usou a IA em cada dia.
- **Assinatura:** plano, situação e datas. Pagamentos serão feitos por um provedor de pagamento; **o número do seu cartão nunca passa pelo Rotinex**.
- **Dados técnicos:** endereço IP, tipo de navegador e registros de acesso e de erro, usados para segurança e para o serviço funcionar.

Não pedimos CPF, endereço, documentos de identidade nem dados bancários para usar o app.

## 3. Para que usamos

- Criar e manter sua conta e mostrar seus dados em todos os seus aparelhos.
- Fazer as contas e os painéis do app (consistência, pontos, gráficos, sugestões de recompensa).
- Organizar automaticamente o que você escreve ou fala na página IA, sempre com a sua confirmação antes de salvar.
- Controlar o teste grátis e a assinatura.
- Proteger o serviço contra abusos, robôs e acessos indevidos.
- Responder aos seus pedidos e dúvidas.

**Não vendemos seus dados, não usamos seus dados para publicidade e não enviamos e-mails de marketing.**

## 4. Bases legais

- **Execução do contrato** (art. 7º, V): conta, dados das áreas, sincronização, assinatura.
- **Consentimento específico e destacado** (art. 11, I): dados de saúde. Você pode retirar esse consentimento quando quiser.
- **Legítimo interesse e obrigação legal** (art. 7º, IX e II; Marco Civil da Internet): segurança e registros de acesso.

## 5. Com quem compartilhamos

Usamos empresas que prestam serviços para o Rotinex funcionar (operadores). Elas só podem usar os dados para nos prestar o serviço:

- **Supabase:** banco de dados, login e armazenamento dos anexos. Os dados ficam em servidores na região de **São Paulo (Brasil)**.
- **Render:** servidor onde roda a nossa API (pode ficar fora do Brasil).
- **Cloudflare:** proteção contra robôs no cadastro e no login (Turnstile) e a inteligência artificial da página IA (Workers AI), que recebe o texto ou áudio só para organizá-lo.
- **Google:** somente se você escolher entrar com o Google.
- **GitHub Pages:** hospedagem das páginas do site (sem seus dados pessoais).
- **Provedor de pagamento (Stripe):** quando a cobrança estiver ativa, para processar a assinatura.

Também podemos compartilhar dados se uma lei ou ordem judicial exigir.

## 6. Transferência internacional

Alguns desses fornecedores podem tratar dados fora do Brasil. Nesses casos, a transferência segue o art. 33 da LGPD, com fornecedores que oferecem garantias de proteção compatíveis com a lei brasileira.

## 7. Por quanto tempo guardamos

- Enquanto sua conta existir.
- Ao **excluir a conta** (Configurações → Excluir minha conta), apagamos na hora seus dados do nosso banco e o seu login.
- Textos e áudios enviados à IA não são guardados por nós depois de organizados.
- Registros técnicos de acesso podem ser guardados por até 6 meses, como exige o Marco Civil da Internet.

## 8. Como protegemos

- Os dados das áreas são **cifrados** (AES-256) antes de irem para o banco.
- Toda comunicação usa conexão segura (HTTPS).
- O app nunca acessa o banco diretamente: tudo passa pela nossa API, que confere quem você é em cada pedido.
- O banco bloqueia qualquer acesso pelas chaves públicas.
- Proteção contra robôs no cadastro e no login.

Nenhum sistema é 100% seguro. Se acontecer um incidente que possa trazer risco a você, avisaremos você e a Autoridade Nacional de Proteção de Dados (ANPD).

## 9. Seus direitos

Pela LGPD (art. 18), você pode:

- confirmar se tratamos seus dados e acessá-los;
- **baixar uma cópia** de tudo (Configurações → Exportar meus dados);
- corrigir dados (direto em cada área do app);
- **excluir a conta e os dados** (Configurações → Excluir minha conta);
- retirar o consentimento para dados de saúde (pelo e-mail de privacidade, enquanto essa opção não chega às Configurações);
- saber com quem compartilhamos seus dados (seção 5);
- pedir informações ou reclamar, inclusive à ANPD.

## 10. Armazenamento no seu aparelho

O app guarda uma cópia dos seus dados no próprio aparelho ou navegador, para abrir rápido e funcionar sem internet. Ao sair da conta, essa cópia é apagada. O site não usa cookies de publicidade nem rastreadores. A proteção contra robôs (Cloudflare Turnstile) pode usar cookies técnicos próprios.

## 11. Idade mínima

O Rotinex é destinado a pessoas com **12 anos ou mais**. Para quem tem de 12 a 17 anos, o uso depende da autorização e do acompanhamento de mãe, pai ou responsável legal, e tratamos os dados sempre no melhor interesse do adolescente (LGPD, art. 14). Não aceitamos contas de crianças com menos de 12 anos; se soubermos de uma, ela será excluída.

## 12. Mudanças nesta política

Se esta política mudar de forma importante, avisaremos no app e pediremos um novo aceite quando a lei exigir. A versão e a data ficam no topo deste texto.
